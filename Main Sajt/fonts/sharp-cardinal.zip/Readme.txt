With Sharp Cardinal I tried to make a font that will benefit from letters with missing lines.
The reason is because I see a lot of fonts having random missing lines that simply didn't add anything special to the font.
And because It's my first attempt at making a font, 
Sharp Cardinal will be under the
"1001Fonts Free For Commercial Use License"
which you can read more about here:
https://www.1001fonts.com/licenses/ffc.html


